from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from Gaussian_model import SSGaussianMixture
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
from sklearn.metrics import accuracy_score
import numpy as np


class BaseClassifier(object):
    def __init__(self):
        self.mus = 0
        self.sigmas = 0
        self.pis = 0
        self.score_ini = 0
        self.preprocess = Pipeline([('vt', VarianceThreshold(threshold=2)), ('scaler', StandardScaler())])
        # 数据预处理 VarianceThreshold(threshold=2))删除方差低于指定阈值2的特征 StandardScaler() 数据标准化，均值为0，方差为1
        # 若阈值较低 说明数据的集中程度大 取值变化较小 因此对于分类或回归任务没有太大贡献 删除低方差的特征 可以减少特征空间的维度 提高模型的
        # 效率和准确率

    # def fit(self, X_train, y_train, X_test, cv_qda=2, cv_meta=2):
    def fit(self, X_train, y_train, su, cv_qda=2, cv_meta=2):
        X_train_org = X_train
        self.preprocess_tune(X_train)
        X_train = self.preprocess.transform(X_train)
        # X_test = self.preprocess.transform(X_test)

        self.cgm = SSGaussianMixture(n_features=X_train.shape[1], n_categories=10)  # 特征255 分类2
        self.cgm.fit(X_train, y_train, su)  # X_train(10000,50),X_test(10000,)
        self.validation(X_train_org, y_train, su) # y_train(10000,)# 降维后无标签数据 y_train X_train 对应标签

    def predict(self, X):
        X = self.preprocess.transform(X)
        return self.cgm.predict_proba(X)[:, 1]

    def preprocess_tune(self, X):
        self.preprocess.fit(X)

    def validation(self, X, y, su):
        X = self.preprocess.transform(X)
        kf = KFold(n_splits=5, shuffle=True)  # 划分5折5次交叉验证
        scores = []
        for train_index, test_index in kf.split(X):
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]
            self.cgm.fit(X_train, y_train, su)
            # y_pred = np.round(self.cgm.predict_proba(X_test)).astype(int)
            y_pred = np.argmax(self.cgm.predict_proba(X_test), axis=1)
            scores.append(accuracy_score(y_test, y_pred))
            self.score_ini = np.array(scores).mean()
            print('validation score = ', self.score_ini)
            # self.score_ini = np.array(scores).mean()
        # self.score = np.array(scores).mean()
        # if self.score > self.score_ini:
        #     self.score_ini = self.score
        #     self.mus = self.cgm.mus
        #     self.sigmas = self.cgm.sigmas
        #     self.pis = self.cgm.pis
